﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

int[] a = { 12, 13, 14, 15, 16 };
for (int i = 1; i < 5; i++)
{
    Console.Write(a[i]);
}
Console.Read();
